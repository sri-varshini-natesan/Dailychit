from django.db import models
from accounts.models import User
import uuid, random, string

def generate_coupon():
    return 'LD' + ''.join(random.choices(string.digits, k=10))

class LuckyDraw(models.Model):
    STATUS_CHOICES = [('draft','Draft'),('published','Published'),('active','Active'),('completed','Completed'),('cancelled','Cancelled')]
    
    name = models.CharField(max_length=200)
    description = models.TextField(null=True, blank=True)
    entry_fee = models.DecimalField(max_digits=10, decimal_places=2)
    max_participants = models.IntegerField(null=True, blank=True)
    draw_date = models.DateTimeField()
    start_date = models.DateField()
    end_date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_draws')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def total_entries(self):
        return self.participations.filter(payment_status='paid').count()

    def __str__(self):
        return self.name

class DrawPrize(models.Model):
    draw = models.ForeignKey(LuckyDraw, on_delete=models.CASCADE, related_name='prizes')
    rank = models.IntegerField()
    prize_name = models.CharField(max_length=200)
    prize_value = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    description = models.TextField(null=True, blank=True)

    class Meta:
        ordering = ['rank']

class Participation(models.Model):
    PAYMENT_STATUS = [('pending','Pending'),('paid','Paid'),('failed','Failed'),('refunded','Refunded')]
    
    draw = models.ForeignKey(LuckyDraw, on_delete=models.CASCADE, related_name='participations')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='participations')
    coupon_number = models.CharField(max_length=20, unique=True, default=generate_coupon)
    entry_fee = models.DecimalField(max_digits=10, decimal_places=2)
    payment_status = models.CharField(max_length=20, choices=PAYMENT_STATUS, default='pending')
    payment_ref = models.CharField(max_length=100, null=True, blank=True)
    participated_at = models.DateTimeField(auto_now_add=True)
    is_winner = models.BooleanField(default=False)

    class Meta:
        unique_together = ['draw', 'user']

class DrawWinner(models.Model):
    CLAIM_STATUS = [('pending','Pending'),('claimed','Claimed'),('distributed','Distributed')]
    
    draw = models.ForeignKey(LuckyDraw, on_delete=models.CASCADE, related_name='winners')
    participation = models.ForeignKey(Participation, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='won_draws')
    prize = models.ForeignKey(DrawPrize, on_delete=models.CASCADE)
    rank = models.IntegerField()
    announced_at = models.DateTimeField(auto_now_add=True)
    claim_status = models.CharField(max_length=20, choices=CLAIM_STATUS, default='pending')
    claimed_at = models.DateTimeField(null=True, blank=True)
