from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
import random

from .models import LuckyDraw, DrawPrize, Participation, DrawWinner
from .serializers import (
    LuckyDrawSerializer,
    DrawPrizeSerializer,
    ParticipationSerializer,
    DrawWinnerSerializer
)


class LuckyDrawViewSet(viewsets.ModelViewSet):
    queryset = LuckyDraw.objects.all().order_by('-created_at')
    serializer_class = LuckyDrawSerializer
    permission_classes = [IsAuthenticated]

    # 🔍 Filtering
    def get_queryset(self):
        qs = super().get_queryset()

        status_f = self.request.query_params.get('status')
        if status_f:
            qs = qs.filter(status=status_f)

        search = self.request.query_params.get('search')
        if search:
            qs = qs.filter(name__icontains=search)

        return qs

    # ✅ CREATE with debug (IMPORTANT)
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)

        if not serializer.is_valid():
            print("❌ SERIALIZER ERROR:", serializer.errors)  # 🔥 DEBUG LINE
            return Response(serializer.errors, status=400)

        self.perform_create(serializer)
        return Response(serializer.data, status=201)

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    # 🎟️ Participate
    @action(detail=True, methods=['post'])
    def participate(self, request, pk=None):
        draw = self.get_object()

        if draw.status not in ['published', 'active']:
            return Response({'error': 'Draw is not open for participation'}, status=400)

        if Participation.objects.filter(draw=draw, user=request.user).exists():
            return Response({'error': 'Already participated in this draw'}, status=400)

        if draw.max_participants and draw.total_entries >= draw.max_participants:
            return Response({'error': 'Draw is full'}, status=400)

        payment_mode = request.data.get('payment_mode', 'upi')

        txn = None

        # 💰 Wallet payment
        if payment_mode == 'wallet':
            from wallet.models import Wallet, WalletTransaction
            wallet, _ = Wallet.objects.get_or_create(user=request.user)

            if wallet.balance < draw.entry_fee:
                return Response({'error': 'Insufficient wallet balance'}, status=400)

            wallet.balance -= draw.entry_fee
            wallet.save()

            WalletTransaction.objects.create(
                wallet=wallet,
                amount=draw.entry_fee,
                transaction_type='debit',
                description=f'Draw entry - {draw.name}',
                balance_after=wallet.balance
            )

        # 💳 Transaction
        from payments.models import Transaction
        txn = Transaction.objects.create(
            user=request.user,
            amount=draw.entry_fee,
            transaction_type='draw_entry',
            payment_mode=payment_mode,
            status='success'
        )

        participation = Participation.objects.create(
            draw=draw,
            user=request.user,
            entry_fee=draw.entry_fee,
            payment_status='paid',
            payment_ref=txn.transaction_id
        )

        from notifications.models import Notification
        Notification.objects.create(
            user=request.user,
            title='Participation Confirmed! 🎟️',
            message=f'You joined {draw.name}. Coupon: {participation.coupon_number}. Good luck!',
            notification_type='general'
        )

        return Response({
            'message': 'Participation successful!',
            'coupon_number': participation.coupon_number,
        })


# 🏆 Conduct Draw
    @action(detail=True, methods=['post'])
    def conduct_draw(self, request, pk=None):
        if not request.user.is_staff:
            return Response({'error': 'Unauthorized'}, status=403)

        draw = self.get_object()

        if draw.status == 'completed':
            return Response({'error': 'Draw already conducted'}, status=400)

        prizes = list(draw.prizes.all().order_by('rank'))

        if not prizes:
            return Response({'error': 'No prizes defined for this draw'}, status=400)

        eligible = list(
            Participation.objects.filter(
                draw=draw,
                payment_status='paid',
                is_winner=False
            )
        )

        if not eligible:
            return Response({'error': 'No eligible participants'}, status=400)

        if len(eligible) < len(prizes):
            return Response({
                'error': f'Only {len(eligible)} participants but {len(prizes)} prizes defined'
            }, status=400)

        selected = random.sample(eligible, len(prizes))
        winners_data = []

        for prize, participation in zip(prizes, selected):
            DrawWinner.objects.create(
                draw=draw,
                participation=participation,
                user=participation.user,
                prize=prize,
                rank=prize.rank
            )

            participation.is_winner = True
            participation.save()

            from notifications.models import Notification
            Notification.objects.create(
                user=participation.user,
                title='🎉 Congratulations! You Won!',
                message=f'You won {prize.prize_name} (₹{prize.prize_value}) in {draw.name}!',
                notification_type='winner'
            )

            winners_data.append({
                'prize_rank': prize.rank,
                'prize_name': prize.prize_name,
                'prize_value': str(prize.prize_value),
                'winner_name': participation.user.get_full_name() or participation.user.username,
                'coupon_id': participation.coupon_number,
            })

        draw.status = 'completed'
        draw.save()

        return Response({
            'message': 'Draw completed successfully!',
            'winners': winners_data
        })


# 🔄 Change Status
    @action(detail=True, methods=['post'])
    def change_status(self, request, pk=None):
        if not request.user.is_staff:
            return Response({'error': 'Unauthorized'}, status=403)

        draw = self.get_object()
        new_status = request.data.get('status')

        if new_status in ['draft', 'published', 'active', 'cancelled']:
            draw.status = new_status
            draw.save()
            return Response({'status': draw.status, 'message': f'Draw {new_status}'})

        return Response({'error': 'Invalid status'}, status=400)


# ---------------- UI Views ----------------

@login_required
def draw_list_view(request):
    draws = LuckyDraw.objects.filter(
        status__in=['published', 'active', 'completed']
    ).order_by('-created_at')

    participated_ids = set(
        Participation.objects.filter(
            user=request.user,
            payment_status='paid'
        ).values_list('draw_id', flat=True)
    )

    return render(request, 'user/draws.html', {
        'draws': draws,
        'participated_ids': participated_ids,
    })


@login_required
def draw_detail_view(request, pk):
    draw = get_object_or_404(LuckyDraw, pk=pk)

    participation = Participation.objects.filter(
        draw=draw,
        user=request.user
    ).first()

    winners = DrawWinner.objects.filter(
        draw=draw
    ).select_related('user', 'prize', 'participation')

    prizes = draw.prizes.all().order_by('rank')

    return render(request, 'user/draw_detail.html', {
        'draw': draw,
        'participation': participation,
        'winners': winners,
        'prizes': prizes,
    })


@login_required
def admin_draws_view(request):
    if not request.user.is_staff:
        return redirect('dashboard')

    return render(request, 'admin/draws.html')