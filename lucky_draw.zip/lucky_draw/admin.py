from django.contrib import admin
from .models import LuckyDraw, DrawPrize, Participation, DrawWinner

@admin.register(LuckyDraw)
class LuckyDrawAdmin(admin.ModelAdmin):
    list_display = ['name', 'entry_fee', 'draw_date', 'status']
    list_filter = ['status']
    search_fields = ['name']

@admin.register(DrawPrize)
class DrawPrizeAdmin(admin.ModelAdmin):
    list_display = ['draw', 'rank', 'prize_name', 'prize_value']

@admin.register(Participation)
class ParticipationAdmin(admin.ModelAdmin):
    list_display = ['draw', 'user', 'coupon_number', 'payment_status', 'participated_at']
    list_filter = ['payment_status']

@admin.register(DrawWinner)
class DrawWinnerAdmin(admin.ModelAdmin):
    list_display = ['draw', 'user', 'prize', 'announced_at']
