from rest_framework import serializers
from .models import LuckyDraw, DrawPrize, Participation, DrawWinner


class DrawPrizeSerializer(serializers.ModelSerializer):
    class Meta:
        model = DrawPrize
        fields = '__all__'


class LuckyDrawSerializer(serializers.ModelSerializer):
    prizes = DrawPrizeSerializer(many=True, read_only=True)
    total_entries = serializers.ReadOnlyField()
    participant_count = serializers.SerializerMethodField()
    prize_count = serializers.SerializerMethodField()

    class Meta:
        model = LuckyDraw
        fields = '__all__'
        read_only_fields = ['created_by']

    def get_participant_count(self, obj):
        return obj.participations.filter(payment_status='paid').count()

    def get_prize_count(self, obj):
        return obj.prizes.count()

    def create(self, validated_data):
        prizes_data = self.context['request'].data.get('prizes', [])
        draw = LuckyDraw.objects.create(**validated_data)
        for p in prizes_data:
            DrawPrize.objects.create(
                draw=draw, rank=p.get('rank', 1),
                prize_name=p.get('prize_name', ''),
                prize_value=p.get('prize_value', 0)
            )
        return draw

    def update(self, instance, validated_data):
        prizes_data = self.context['request'].data.get('prizes', [])
        for attr, val in validated_data.items():
            setattr(instance, attr, val)
        instance.save()
        if prizes_data:
            instance.prizes.all().delete()
            for p in prizes_data:
                DrawPrize.objects.create(
                    draw=instance, rank=p.get('rank', 1),
                    prize_name=p.get('prize_name', ''),
                    prize_value=p.get('prize_value', 0)
                )
        return instance


class ParticipationSerializer(serializers.ModelSerializer):
    user_name = serializers.SerializerMethodField()
    draw_name = serializers.CharField(source='draw.name', read_only=True)

    class Meta:
        model = Participation
        fields = '__all__'
        read_only_fields = ['user', 'coupon_number', 'is_winner']

    def get_user_name(self, obj):
        return obj.user.get_full_name() or obj.user.username


class DrawWinnerSerializer(serializers.ModelSerializer):
    user_name = serializers.SerializerMethodField()
    prize_name = serializers.CharField(source='prize.prize_name', read_only=True)
    prize_value = serializers.CharField(source='prize.prize_value', read_only=True)
    prize_rank = serializers.IntegerField(source='prize.rank', read_only=True)
    coupon_number = serializers.CharField(source='participation.coupon_number', read_only=True)

    class Meta:
        model = DrawWinner
        fields = '__all__'

    def get_user_name(self, obj):
        return obj.user.get_full_name() or obj.user.username
