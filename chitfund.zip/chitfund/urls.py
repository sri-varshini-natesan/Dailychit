from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework.routers import DefaultRouter

from accounts.views import (UserViewSet, api_register, api_login, api_send_otp,
    api_verify_otp, api_profile, landing_page, login_page, register_page,
    logout_view, dashboard_view, admin_dashboard_view, profile_view, admin_members_view)
from chits.views import ChitViewSet, InstallmentViewSet, chit_list_view, chit_detail_view, admin_chits_view
from lucky_draw.views import LuckyDrawViewSet, draw_list_view, draw_detail_view, admin_draws_view
from payments.views import TransactionViewSet, payment_history_view, admin_payments_view
from wallet.views import get_wallet, add_money, wallet_view
from notifications.views import get_notifications, mark_read, mark_all_read, notifications_view
from reports.views import reports_dashboard, reports_view, export_report, export_members_csv
from payments.views import refund_transaction, payment_receipt
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

router = DefaultRouter()
router.register('users', UserViewSet)
router.register('chits', ChitViewSet)
router.register('installments', InstallmentViewSet)
router.register('draws', LuckyDrawViewSet)
router.register('transactions', TransactionViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),

    # API
    path('api/', include(router.urls)),
    path('api/auth/register/', api_register),
    path('api/auth/login/', api_login),
    path('api/auth/send-otp/', api_send_otp),
    path('api/auth/verify-otp/', api_verify_otp),
    path('api/profile/', api_profile),
    path('api/wallet/', get_wallet),
    path('api/wallet/add/', add_money),
    path('api/notifications/', get_notifications),
    path('api/notifications/<int:pk>/read/', mark_read),
    path('api/notifications/read-all/', mark_all_read),

    # JWT
    path('api/token/', TokenObtainPairView.as_view()),
    path('api/token/refresh/', TokenRefreshView.as_view()),

    # User Pages
    path('', landing_page, name='landing'),
    path('login/', login_page, name='login'),
    path('register/', register_page, name='register'),
    path('logout/', logout_view, name='logout'),
    path('dashboard/', dashboard_view, name='dashboard'),
    path('my-chits/', chit_list_view, name='my_chits'),
    path('my-chits/<int:pk>/', chit_detail_view, name='chit_detail'),
    path('payments/', payment_history_view, name='payments'),
    path('wallet/', wallet_view, name='wallet'),
    path('lucky-draws/', draw_list_view, name='draws'),
    path('lucky-draws/<int:pk>/', draw_detail_view, name='draw_detail'),
    path('notifications/', notifications_view, name='notifications'),

    # Admin Panel
    path('admin-panel/', admin_dashboard_view, name='admin_dashboard'),
    path('admin-panel/chits/', admin_chits_view, name='admin_chits'),
    path('admin-panel/draws/', admin_draws_view, name='admin_draws'),
    path('admin-panel/payments/', admin_payments_view, name='admin_payments'),
    path('admin-panel/reports/', reports_view, name='admin_reports'),

    # Reports & Exports
    path('reports/dashboard/', reports_dashboard, name='reports_dashboard'),
    path('reports/export/<str:report_type>/', export_report, name='export_report'),
    path('reports/export/members/', export_members_csv, name='export_members'),

    # Profile & Members
    path('profile/', profile_view, name='profile'),
    path('admin-panel/members/', admin_members_view, name='admin_members'),

    # Payment Receipt & Refund
    path('payments/receipt/<int:pk>/', payment_receipt, name='payment_receipt'),
    path('api/transactions/<int:pk>/refund/', refund_transaction, name='refund_transaction'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
# (already imported above — need to add these two routes separately)
