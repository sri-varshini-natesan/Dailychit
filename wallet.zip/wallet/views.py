from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Wallet, WalletTransaction
from .serializers import WalletSerializer, WalletTransactionSerializer


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_wallet(request):
    wallet, _ = Wallet.objects.get_or_create(user=request.user)
    transactions = WalletTransaction.objects.filter(wallet=wallet).order_by('-created_at')[:20]
    return Response({
        'balance': float(wallet.balance),
        'total_added': float(wallet.total_added),
        'total_withdrawn': float(wallet.total_withdrawn),
        'transactions': WalletTransactionSerializer(transactions, many=True).data
    })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def add_money(request):
    amount = float(request.data.get('amount', 0))
    payment_mode = request.data.get('payment_mode', 'upi')
    if amount <= 0:
        return Response({'error': 'Amount must be greater than 0'}, status=400)
    if amount > 100000:
        return Response({'error': 'Maximum ₹1,00,000 per transaction'}, status=400)

    wallet, _ = Wallet.objects.get_or_create(user=request.user)
    wallet.balance += amount
    wallet.total_added += amount
    wallet.save()

    from payments.models import Transaction
    txn = Transaction.objects.create(
        user=request.user, amount=amount,
        transaction_type='wallet_topup', payment_mode=payment_mode, status='success'
    )

    WalletTransaction.objects.create(
        wallet=wallet, amount=amount, transaction_type='credit',
        description=f'Wallet top-up via {payment_mode.upper()}',
        reference=txn.transaction_id, balance_after=wallet.balance
    )

    from notifications.models import Notification
    Notification.objects.create(
        user=request.user, title='Wallet Topped Up ✅',
        message=f'₹{amount:.0f} added to your wallet. New balance: ₹{wallet.balance:.0f}',
        notification_type='payment_success'
    )

    return Response({
        'message': f'₹{amount:.0f} added successfully!',
        'balance': float(wallet.balance)
    })


@login_required
def wallet_view(request):
    wallet, _ = Wallet.objects.get_or_create(user=request.user)
    transactions = WalletTransaction.objects.filter(wallet=wallet).order_by('-created_at')
    return render(request, 'user/wallet.html', {'wallet': wallet, 'transactions': transactions})
