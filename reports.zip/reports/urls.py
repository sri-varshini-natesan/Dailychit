from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.reports_view, name='reports_view'),
    path('export/<str:report_type>/', views.export_report, name='export_report'),
    path('export/members/csv/', views.export_members_csv, name='export_members_csv'),
]
