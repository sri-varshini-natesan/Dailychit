import csv
from datetime import datetime, timedelta
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.db.models import Sum, Count
from django.db.models.functions import TruncMonth
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from accounts.models import User
from chits.models import Chit, ChitInstallment
from lucky_draw.models import LuckyDraw, Participation, DrawWinner
from payments.models import Transaction
from wallet.models import Wallet


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def reports_dashboard(request):
    total_collection = Transaction.objects.filter(status='completed').aggregate(total=Sum('amount'))['total'] or 0
    pending_amount = ChitInstallment.objects.filter(status='pending').aggregate(total=Sum('amount'))['total'] or 0
    total_members = User.objects.filter(role='user').count()
    active_chits = Chit.objects.filter(status='active').count()
    draw_entries = Participation.objects.filter(payment_status='completed').count()
    winners = DrawWinner.objects.count()

    six_months_ago = datetime.now() - timedelta(days=180)
    monthly_qs = Transaction.objects.filter(status='completed', created_at__gte=six_months_ago).annotate(
        month=TruncMonth('created_at')).values('month').annotate(amount=Sum('amount')).order_by('month')
    monthly_data = [{'month': item['month'].strftime('%b %Y'), 'amount': float(item['amount'] or 0)} for item in monthly_qs]

    payment_modes_qs = Transaction.objects.filter(status='completed').values('payment_mode').annotate(count=Count('id'))
    payment_modes = {item['payment_mode']: item['count'] for item in payment_modes_qs if item['payment_mode']}

    chit_status_qs = Chit.objects.values('status').annotate(count=Count('id'))
    chit_status = {item['status']: item['count'] for item in chit_status_qs}

    member_trend_qs = User.objects.filter(role='user', date_joined__gte=six_months_ago).annotate(
        month=TruncMonth('date_joined')).values('month').annotate(count=Count('id')).order_by('month')
    member_trend = [{'month': item['month'].strftime('%b'), 'count': item['count']} for item in member_trend_qs]

    draw_entries_data = [{'name': d.name[:15], 'entries': d.participant_count} for d in LuckyDraw.objects.all()[:5]]

    top_members_qs = Transaction.objects.filter(status='completed', transaction_type='chit_payment').values(
        'user__id','user__first_name','user__last_name','user__username').annotate(
        total_paid=Sum('amount'), chit_count=Count('id')).order_by('-total_paid')[:10]
    top_members = [{
        'name': f"{m['user__first_name']} {m['user__last_name']}".strip() or m['user__username'],
        'total_paid': float(m['total_paid'] or 0), 'chit_count': m['chit_count']
    } for m in top_members_qs]

    return Response({
        'total_collection': float(total_collection), 'pending_amount': float(pending_amount),
        'total_members': total_members, 'active_chits': active_chits,
        'draw_entries': draw_entries, 'winners': winners,
        'monthly_data': monthly_data, 'payment_modes': payment_modes,
        'chit_status': chit_status, 'member_trend': member_trend,
        'draw_entries_data': draw_entries_data, 'top_members': top_members,
    })


def reports_view(request):
    if not request.user.is_authenticated or request.user.role != 'admin':
        return redirect('/login/')
    return render(request, 'admin/reports.html')


def export_report(request, report_type):
    if not request.user.is_authenticated:
        return HttpResponse('Unauthorized', status=401)
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{report_type}_{datetime.now().strftime("%Y%m%d")}.csv"'
    writer = csv.writer(response)

    if report_type in ('members', 'all'):
        writer.writerow(['#', 'Name', 'Username', 'Phone', 'Email', 'Status', 'KYC', 'Joined'])
        for i, u in enumerate(User.objects.filter(role='user').order_by('-date_joined'), 1):
            writer.writerow([i, f"{u.first_name} {u.last_name}".strip() or u.username, u.username,
                             u.phone or '', u.email, u.status, 'Yes' if getattr(u, 'is_kyc_verified', False) else 'No',
                             u.date_joined.strftime('%d-%m-%Y')])
    elif report_type == 'chits':
        writer.writerow(['#', 'Name', 'Weekly Amt', 'Total Members', 'Current', 'Weeks', 'Start', 'Status'])
        for i, c in enumerate(Chit.objects.all(), 1):
            writer.writerow([i, c.name, c.weekly_amount, c.total_members, c.current_members, c.total_weeks, c.start_date, c.status])
    elif report_type == 'transactions':
        writer.writerow(['#', 'TXN ID', 'User', 'Type', 'Amount', 'Mode', 'Status', 'Date'])
        for i, t in enumerate(Transaction.objects.all().order_by('-created_at'), 1):
            writer.writerow([i, t.transaction_id, t.user.username, t.transaction_type,
                             t.amount, t.payment_mode or '', t.status, t.created_at.strftime('%d-%m-%Y %H:%M')])
    elif report_type == 'draws':
        writer.writerow(['#', 'Name', 'Entry Fee', 'Draw Date', 'Participants', 'Status'])
        for i, d in enumerate(LuckyDraw.objects.all(), 1):
            writer.writerow([i, d.name, d.entry_fee, d.draw_date, d.participant_count, d.status])
    elif report_type == 'winners':
        writer.writerow(['#', 'Draw', 'Winner', 'Phone', 'Prize', 'Rank', 'Coupon'])
        for i, w in enumerate(DrawWinner.objects.select_related('draw','participant__user','prize').all(), 1):
            writer.writerow([i, w.draw.name,
                             f"{w.participant.user.first_name} {w.participant.user.last_name}".strip() or w.participant.user.username,
                             w.participant.user.phone or '',
                             w.prize.prize_name if w.prize else '', w.prize.rank if w.prize else '',
                             w.participant.coupon_id])
    elif report_type == 'wallet':
        writer.writerow(['#', 'User', 'Balance', 'Updated'])
        for i, wlt in enumerate(Wallet.objects.select_related('user').all(), 1):
            writer.writerow([i, wlt.user.username, wlt.balance, wlt.updated_at.strftime('%d-%m-%Y')])
    return response


def export_members_csv(request):
    return export_report(request, 'members')
