from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Notification

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_notifications(request):
    notifs = Notification.objects.filter(user=request.user).order_by('-created_at')[:20]
    data = [{'id':n.id,'title':n.title,'message':n.message,'type':n.notification_type,'is_read':n.is_read,'created_at':n.created_at.isoformat()} for n in notifs]
    unread = Notification.objects.filter(user=request.user, is_read=False).count()
    return Response({'notifications': data, 'unread_count': unread})

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def mark_read(request, pk):
    try:
        notif = Notification.objects.get(id=pk, user=request.user)
        notif.is_read = True
        notif.save()
        return Response({'message':'Marked as read'})
    except Notification.DoesNotExist:
        return Response({'error':'Not found'}, status=404)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def mark_all_read(request):
    Notification.objects.filter(user=request.user, is_read=False).update(is_read=True)
    return Response({'message':'All marked as read'})

@login_required
def notifications_view(request):
    notifs = Notification.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'user/notifications.html', {'notifications': notifs})
