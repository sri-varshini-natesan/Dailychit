from django.db import models
from accounts.models import User

class Notification(models.Model):
    TYPE_CHOICES = [('payment_due','Payment Due'),('payment_success','Payment Success'),('payment_failed','Payment Failed'),('winner','Winner'),('new_chit','New Chit'),('new_draw','New Draw'),('general','General')]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    title = models.CharField(max_length=200)
    message = models.TextField()
    notification_type = models.CharField(max_length=30, choices=TYPE_CHOICES, default='general')
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
