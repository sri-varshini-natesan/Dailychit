// CSRF Token setup for AJAX
function getCookie(name) {
    let v = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
    return v ? v[2] : null;
}

$.ajaxSetup({ headers: { 'X-CSRFToken': getCookie('csrftoken') } });

// Sidebar toggle
$(document).ready(function() {
    $('#sidebarToggle').on('click', function() {
        $('.sidebar').toggleClass('open');
        $('.sidebar-overlay').toggleClass('show');
    });
    $('.sidebar-overlay').on('click', function() {
        $('.sidebar').removeClass('open');
        $(this).removeClass('show');
    });

    // Load notifications
    loadNotifications();
    
    // Auto-dismiss alerts
    setTimeout(function() { $('.alert').fadeOut(); }, 4000);
});

function loadNotifications() {
    if (!$('#notifBadge').length) return;
    $.get('/api/notifications/', function(data) {
        if (data.unread_count > 0) {
            $('#notifBadge').show().text(data.unread_count);
        }
        let html = '';
        data.notifications.slice(0,5).forEach(function(n) {
            let icon = n.type === 'payment_success' ? '✅' : n.type === 'winner' ? '🏆' : n.type === 'payment_due' ? '⏰' : '🔔';
            html += `<div class="notif-item ${n.is_read ? '' : 'unread'}" onclick="markRead(${n.id}, this)">
                <div class="notif-icon">${icon}</div>
                <div><div class="notif-title">${n.title}</div><div class="notif-msg">${n.message}</div></div>
            </div>`;
        });
        $('#notifDropdown').html(html || '<div class="p-3 text-muted text-center">No notifications</div>');
    }).fail(function(){});
}

function markRead(id, el) {
    $.post('/api/notifications/' + id + '/read/', function() {
        $(el).removeClass('unread');
        let count = parseInt($('#notifBadge').text()) - 1;
        if (count <= 0) $('#notifBadge').hide();
        else $('#notifBadge').text(count);
    });
}

function markAllRead() {
    $.post('/api/notifications/read-all/', function() {
        $('#notifBadge').hide();
        $('.notif-item').removeClass('unread');
        showToast('All notifications marked as read', 'success');
    });
}

// Toast notification
function showToast(msg, type='info') {
    let colors = {success:'#28C76F', error:'#EA5455', info:'#00CFE8', warning:'#FF9F43'};
    let toast = $(`<div style="position:fixed;bottom:24px;right:24px;background:${colors[type]};color:#fff;padding:14px 20px;border-radius:12px;font-size:14px;font-weight:600;z-index:9999;box-shadow:0 4px 20px rgba(0,0,0,0.2);max-width:320px;">${msg}</div>`);
    $('body').append(toast);
    setTimeout(function() { toast.fadeOut(400, function() { $(this).remove(); }); }, 3000);
}

// Payment Modal
function openPaymentModal(installmentId, amount, chitName, weekNum) {
    $('#payInstallmentId').val(installmentId);
    $('#payAmount').text('₹' + parseFloat(amount).toLocaleString('en-IN'));
    $('#payChitName').text(chitName + ' - Week ' + weekNum);
    $('#paymentModal').modal('show');
}

function submitPayment() {
    let id = $('#payInstallmentId').val();
    let mode = $('input[name="paymentMode"]:checked').val() || 'upi';
    
    $.ajax({
        url: '/api/installments/' + id + '/pay/',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({payment_mode: mode}),
        headers: {'Authorization': 'Bearer ' + localStorage.getItem('access_token')},
        success: function(data) {
            $('#paymentModal').modal('hide');
            showToast('Payment successful! TXN: ' + data.transaction_id, 'success');
            setTimeout(() => location.reload(), 1500);
        },
        error: function(xhr) {
            showToast(xhr.responseJSON?.error || 'Payment failed', 'error');
        }
    });
}

// Participate in draw
function participateInDraw(drawId, drawName, entryFee) {
    $('#participateDrawId').val(drawId);
    $('#participateDrawName').text(drawName);
    $('#participateEntryFee').text('₹' + parseFloat(entryFee).toLocaleString('en-IN'));
    $('#participateModal').modal('show');
}

function submitParticipation() {
    let id = $('#participateDrawId').val();
    let mode = $('input[name="drawPayMode"]:checked').val() || 'upi';
    
    $.ajax({
        url: '/api/draws/' + id + '/participate/',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({payment_mode: mode}),
        headers: {'Authorization': 'Bearer ' + localStorage.getItem('access_token')},
        success: function(data) {
            $('#participateModal').modal('hide');
            showToast('Participation successful! Coupon: ' + data.coupon_number, 'success');
            setTimeout(() => location.reload(), 1500);
        },
        error: function(xhr) {
            showToast(xhr.responseJSON?.error || 'Participation failed', 'error');
        }
    });
}

// Add wallet money
function submitAddMoney() {
    let amount = parseFloat($('#addMoneyAmount').val());
    let mode = $('input[name="walletMode"]:checked').val() || 'upi';
    if (!amount || amount <= 0) { showToast('Enter valid amount', 'error'); return; }
    
    $.ajax({
        url: '/api/wallet/add/',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({amount: amount, payment_mode: mode}),
        headers: {'Authorization': 'Bearer ' + localStorage.getItem('access_token')},
        success: function(data) {
            $('#addMoneyModal').modal('hide');
            showToast('₹' + amount + ' added to wallet!', 'success');
            setTimeout(() => location.reload(), 1500);
        },
        error: function(xhr) { showToast('Failed to add money', 'error'); }
    });
}

// Admin: Create Chit
function submitCreateChit() {
    let data = {
        name: $('#chitName').val(),
        total_members: parseInt($('#chitMembers').val()),
        weekly_amount: parseFloat($('#chitAmount').val()),
        total_weeks: parseInt($('#chitWeeks').val()),
        start_date: $('#chitStartDate').val(),
        description: $('#chitDesc').val() || '',
        status: 'active'
    };
    
    $.ajax({
        url: '/api/chits/',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(data),
        headers: {'Authorization': 'Bearer ' + localStorage.getItem('access_token'), 'X-CSRFToken': getCookie('csrftoken')},
        success: function(data) {
            $('#createChitModal').modal('hide');
            showToast('Chit created successfully!', 'success');
            setTimeout(() => location.reload(), 1200);
        },
        error: function(xhr) {
            let err = xhr.responseJSON;
            showToast(JSON.stringify(err), 'error');
        }
    });
}

// Admin: Create Lucky Draw
function submitCreateDraw() {
    let prizes = [];
    $('.prize-row').each(function(i) {
        prizes.push({
            rank: i+1,
            prize_name: $(this).find('.prize-name').val(),
            prize_value: parseFloat($(this).find('.prize-value').val()) || 0
        });
    });
    
    let data = {
        name: $('#drawName').val(),
        entry_fee: parseFloat($('#drawEntryFee').val()),
        max_participants: parseInt($('#drawMaxPart').val()) || null,
        draw_date: $('#drawDate').val() + ':00',
        start_date: $('#drawStartDate').val(),
        end_date: $('#drawEndDate').val(),
        description: $('#drawDesc').val() || '',
        status: 'published'
    };
    
    $.ajax({
        url: '/api/draws/',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(data),
        headers: {'Authorization': 'Bearer ' + localStorage.getItem('access_token'), 'X-CSRFToken': getCookie('csrftoken')},
        success: function(drawData) {
            // Add prizes
            prizes.forEach(function(prize) {
                if (prize.prize_name) {
                    $.ajax({
                        url: '/api/',
                        method: 'POST',
                        contentType: 'application/json',
                        data: JSON.stringify({...prize, draw: drawData.id}),
                        headers: {'Authorization': 'Bearer ' + localStorage.getItem('access_token')}
                    });
                }
            });
            $('#createDrawModal').modal('hide');
            showToast('Lucky Draw created!', 'success');
            setTimeout(() => location.reload(), 1200);
        },
        error: function(xhr) { showToast(JSON.stringify(xhr.responseJSON), 'error'); }
    });
}

// Conduct Draw
function conductDraw(drawId, drawName) {
    if (!confirm('Are you sure you want to conduct the draw for "' + drawName + '"? This cannot be undone!')) return;
    
    $.ajax({
        url: '/api/draws/' + drawId + '/conduct_draw/',
        method: 'POST',
        headers: {'Authorization': 'Bearer ' + localStorage.getItem('access_token'), 'X-CSRFToken': getCookie('csrftoken')},
        success: function(data) {
            showToast('Draw conducted! ' + data.winners.length + ' winners selected.', 'success');
            setTimeout(() => location.reload(), 2000);
        },
        error: function(xhr) { showToast(xhr.responseJSON?.error || 'Draw failed', 'error'); }
    });
}

// Toggle member status
function toggleMemberStatus(userId, currentStatus) {
    $.ajax({
        url: '/api/users/' + userId + '/toggle_status/',
        method: 'POST',
        headers: {'Authorization': 'Bearer ' + localStorage.getItem('access_token'), 'X-CSRFToken': getCookie('csrftoken')},
        success: function(data) {
            showToast('Status updated to ' + data.status, 'success');
            setTimeout(() => location.reload(), 1000);
        }
    });
}

// Print receipt
function printReceipt(txnId) {
    window.print();
}

// Search table
function searchTable(inputId, tableId) {
    let filter = $('#' + inputId).val().toLowerCase();
    $('#' + tableId + ' tbody tr').each(function() {
        let text = $(this).text().toLowerCase();
        $(this).toggle(text.includes(filter));
    });
}
