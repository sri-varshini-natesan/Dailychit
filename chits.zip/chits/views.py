from rest_framework import viewsets, status
from rest_framework.decorators import api_view, permission_classes, action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from .models import Chit, ChitMembership, ChitInstallment
from .serializers import ChitSerializer, ChitMembershipSerializer, InstallmentSerializer
import datetime

class ChitViewSet(viewsets.ModelViewSet):
    queryset = Chit.objects.all().order_by('-created_at')
    serializer_class = ChitSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        chit = serializer.save(created_by=self.request.user)
        self._generate_installments(chit)

    def _generate_installments(self, chit):
        memberships = chit.memberships.filter(status='active')
        for membership in memberships:
            for week in range(1, chit.total_weeks + 1):
                due_date = chit.start_date + datetime.timedelta(weeks=week-1)
                ChitInstallment.objects.get_or_create(
                    chit=chit, membership=membership, week_number=week,
                    defaults={'due_date': due_date, 'amount': chit.weekly_amount}
                )

    @action(detail=True, methods=['post'])
    def add_member(self, request, pk=None):
        chit = self.get_object()
        user_id = request.data.get('user_id')
        from accounts.models import User
        user = get_object_or_404(User, id=user_id)
        if chit.current_members >= chit.total_members:
            return Response({'error':'Chit is full'}, status=400)
        membership, created = ChitMembership.objects.get_or_create(
            chit=chit, user=user,
            defaults={'member_number': chit.current_members + 1}
        )
        if not created:
            return Response({'error':'User already a member'}, status=400)
        # Generate installments for new member
        for week in range(1, chit.total_weeks + 1):
            due_date = chit.start_date + datetime.timedelta(weeks=week-1)
            ChitInstallment.objects.get_or_create(
                chit=chit, membership=membership, week_number=week,
                defaults={'due_date': due_date, 'amount': chit.weekly_amount}
            )
        return Response({'message':'Member added', 'membership': ChitMembershipSerializer(membership).data})

    @action(detail=True, methods=['post'])
    def change_status(self, request, pk=None):
        chit = self.get_object()
        new_status = request.data.get('status')
        if new_status in ['active','paused','completed','cancelled']:
            chit.status = new_status
            chit.save()
            return Response({'status': chit.status})
        return Response({'error':'Invalid status'}, status=400)

class InstallmentViewSet(viewsets.ModelViewSet):
    queryset = ChitInstallment.objects.all().order_by('-due_date')
    serializer_class = InstallmentSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        qs = super().get_queryset()
        if not self.request.user.is_staff:
            qs = qs.filter(membership__user=self.request.user)
        chit_id = self.request.query_params.get('chit_id')
        if chit_id:
            qs = qs.filter(chit_id=chit_id)
        status_f = self.request.query_params.get('status')
        if status_f:
            qs = qs.filter(status=status_f)
        return qs

    @action(detail=True, methods=['post'])
    def pay(self, request, pk=None):
        installment = self.get_object()
        amount = float(request.data.get('amount', installment.amount))
        payment_mode = request.data.get('payment_mode', 'upi')
        
        if installment.status == 'paid':
            return Response({'error':'Already paid'}, status=400)
        
        from payments.models import Transaction
        from wallet.models import Wallet, WalletTransaction
        import uuid
        
        if payment_mode == 'wallet':
            wallet, _ = Wallet.objects.get_or_create(user=request.user)
            if wallet.balance < amount:
                return Response({'error':'Insufficient wallet balance'}, status=400)
            wallet.balance -= amount
            wallet.save()
            WalletTransaction.objects.create(
                wallet=wallet, amount=amount, transaction_type='debit',
                description=f'Chit payment - {installment.chit.name} Week {installment.week_number}',
                balance_after=wallet.balance
            )
        
        txn = Transaction.objects.create(
            user=request.user, amount=amount, transaction_type='chit_payment',
            payment_mode=payment_mode, status='success',
            reference_id=installment.id, reference_type='installment'
        )
        
        installment.paid_amount = amount
        installment.status = 'paid'
        installment.paid_date = timezone.now()
        installment.payment_ref = txn.transaction_id
        installment.save()
        
        from notifications.models import Notification
        Notification.objects.create(
            user=request.user, title='Payment Successful',
            message=f'Payment of ₹{amount} for {installment.chit.name} Week {installment.week_number} is successful.',
            notification_type='payment_success'
        )
        
        return Response({'message':'Payment successful', 'transaction_id': txn.transaction_id})

# Template Views
@login_required
def chit_list_view(request):
    if request.user.is_staff:
        chits = Chit.objects.all().order_by('-created_at')
    else:
        memberships = ChitMembership.objects.filter(user=request.user, status='active').values_list('chit_id', flat=True)
        chits = Chit.objects.filter(id__in=memberships)
    return render(request, 'user/chits.html', {'chits': chits})

@login_required
def chit_detail_view(request, pk):
    chit = get_object_or_404(Chit, pk=pk)
    membership = None
    installments = []
    if not request.user.is_staff:
        membership = ChitMembership.objects.filter(chit=chit, user=request.user).first()
        if membership:
            installments = ChitInstallment.objects.filter(membership=membership).order_by('week_number')
    else:
        installments = ChitInstallment.objects.filter(chit=chit).order_by('week_number')
    return render(request, 'user/chit_detail.html', {
        'chit': chit, 'membership': membership, 'installments': installments,
        'members': chit.memberships.filter(status='active').select_related('user')
    })

@login_required
def admin_chits_view(request):
    if not request.user.is_staff:
        return redirect('dashboard')
    chits = Chit.objects.all().order_by('-created_at')
    return render(request, 'admin/chits.html', {'chits': chits})
