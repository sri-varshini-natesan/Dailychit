from rest_framework import serializers
from .models import Chit, ChitMembership, ChitInstallment
from accounts.serializers import UserSerializer

class ChitSerializer(serializers.ModelSerializer):
    current_members = serializers.ReadOnlyField()
    total_value = serializers.ReadOnlyField()
    
    class Meta:
        model = Chit
        fields = '__all__'
        read_only_fields = ['created_by']

class ChitMembershipSerializer(serializers.ModelSerializer):
    user_name = serializers.CharField(source='user.get_full_name', read_only=True)
    user_phone = serializers.CharField(source='user.phone', read_only=True)
    
    class Meta:
        model = ChitMembership
        fields = '__all__'

class InstallmentSerializer(serializers.ModelSerializer):
    user_name = serializers.CharField(source='membership.user.get_full_name', read_only=True)
    chit_name = serializers.CharField(source='chit.name', read_only=True)
    
    class Meta:
        model = ChitInstallment
        fields = '__all__'
