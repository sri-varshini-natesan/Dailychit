from django.db import models
from accounts.models import User

class Chit(models.Model):
    STATUS_CHOICES = [('draft','Draft'),('active','Active'),('paused','Paused'),('completed','Completed'),('cancelled','Cancelled')]
    
    name = models.CharField(max_length=200)
    description = models.TextField(null=True, blank=True)
    total_members = models.IntegerField()
    weekly_amount = models.DecimalField(max_digits=12, decimal_places=2)
    total_weeks = models.IntegerField()
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_chits')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def total_value(self):
        return self.total_members * self.weekly_amount * self.total_weeks

    @property
    def current_members(self):
        return self.memberships.filter(status='active').count()

    def __str__(self):
        return self.name

class ChitMembership(models.Model):
    STATUS_CHOICES = [('active','Active'),('inactive','Inactive'),('left','Left')]
    
    chit = models.ForeignKey(Chit, on_delete=models.CASCADE, related_name='memberships')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='chit_memberships')
    member_number = models.IntegerField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active')
    joined_date = models.DateField(auto_now_add=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['chit', 'user']

class ChitInstallment(models.Model):
    STATUS_CHOICES = [('pending','Pending'),('paid','Paid'),('overdue','Overdue'),('waived','Waived')]
    
    chit = models.ForeignKey(Chit, on_delete=models.CASCADE, related_name='installments')
    membership = models.ForeignKey(ChitMembership, on_delete=models.CASCADE, related_name='installments')
    week_number = models.IntegerField()
    due_date = models.DateField()
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    paid_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    paid_date = models.DateTimeField(null=True, blank=True)
    payment_ref = models.CharField(max_length=100, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
