from django.contrib import admin
from .models import Chit, ChitMembership, ChitInstallment

@admin.register(Chit)
class ChitAdmin(admin.ModelAdmin):
    list_display = ['name', 'weekly_amount', 'total_members', 'total_weeks', 'status', 'start_date']
    list_filter = ['status']
    search_fields = ['name']

@admin.register(ChitMembership)
class ChitMembershipAdmin(admin.ModelAdmin):
    list_display = ['chit', 'user', 'joined_date', 'status']
    list_filter = ['status']

@admin.register(ChitInstallment)
class ChitInstallmentAdmin(admin.ModelAdmin):
    list_display = ['membership', 'week_number', 'amount', 'due_date', 'status']
    list_filter = ['status']
